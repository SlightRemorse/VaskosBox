package ballsAndBoxes;
import java.util.LinkedList;
/**
 * @constructor int boxSize
 */
public class Box {
	private int size;
	private LinkedList<Ball> content;
	public Box(int boxSize) {
		this.size=boxSize;
		this.content = new LinkedList<Ball>();
	}
	/**
	 * @return int remainingCapacity
	 */
	public int getCapacity() {
		return size-content.size();  
	}
	/**
	 * @return int boxSize
	 */
	public int getSize() {
		return size;
	}
	/**
	 * Clears the box of any balls.
	 */
	public void clear() {
		for(int i=0; i<content.size(); i++) content.get(i).setInside(false);
		content.clear();
	}
	/**
	 * Adds a ball to the box.
	 * 
	 * @param Ball
	 * 
	 * Returns a sysout in case an error occurs.
	 */
	public void add(Ball ball) {
		if(size-content.size()<1) {
			System.out.println("Box is already full.");
		} else {
			if(ball.isInside()==false) {
				content.add(ball);
				ball.setInside(true);
			} else {
				System.out.println("Ball is already inside a box.");
			}
		}
	}
	/**
	 * Removes a ball from the box.
	 * 
	 * @param Ball
	 * 
	 * Returns a sysout in case an error occurs.
	 */
	public void remove(Ball ball) {
		if(content.contains(ball)==false) {
			System.out.println("Ball is not in this box.");
		} else {
			if(ball.isInside()==true) {
				content.remove(ball);
				ball.setInside(false);
			} else {
				System.out.println("Ball is not inside a box.");
			}
		}
	}
	/**
	 * @param Ball
	 * @return boolean ballIsInside
	 */
	public boolean contains(Ball ball) {
		if(content.contains(ball)==true) return true;
		else return false;
	}
}
