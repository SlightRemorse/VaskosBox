package ballsAndBoxes;

public class MainClass {

	/**
	 * includes an example
	 * The main class of this program.
	 * Write whatever uses of the Ball and Box classes here.
	 */
	public static void main(String[] args) {
		/*
		Ball nball = new Ball("Green");
		Box nbox = new Box(5);
		System.out.println("nball is used?: " + nball.isInside());
		System.out.println("nball is in nbox?: " + nbox.contains(nball));
		System.out.println("nbox size: " + nbox.getSize());
		System.out.println("nbox capacity: " + nbox.getCapacity());
		System.out.println("Adding nball to nbox.");
		nbox.add(nball);
		System.out.println("nball is used?: " + nball.isInside());
		System.out.println("nball is in nbox?: " + nbox.contains(nball));
		System.out.println("nbox size: " + nbox.getSize());
		System.out.println("nbox capacity: " + nbox.getCapacity());
		System.out.println("Adding nball to nbox. Should cause an error.");
		nbox.add(nball);
		System.out.println("Removing nball from nbox");
		nbox.remove(nball);
		System.out.println("nball is used?: " + nball.isInside());
		System.out.println("nball is in nbox?: " + nbox.contains(nball));
		System.out.println("nbox size: " + nbox.getSize());
		System.out.println("nbox capacity: " + nbox.getCapacity());
		System.out.println("Removing nball from nbox again. Should cause error.");
		nbox.remove(nball);
		*/
	}

}
