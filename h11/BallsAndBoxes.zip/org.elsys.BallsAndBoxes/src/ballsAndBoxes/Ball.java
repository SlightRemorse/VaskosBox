package ballsAndBoxes;

/**
 * @constructor String ballColor
 */
public class Ball {
	private String color;
	private boolean inside;
	public Ball(String color_) {
		color=color_;
		inside=false;
	}
	/**
	 * Returns ball color.
	 * @return ballColor
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param String color_
	 * Sets ball to @color_
	 */
	public void setColor(String color_) {
		color = color_;
	}
	/**
	 * Function used in the Box class.
	 * @param boolean inside
	 */
	public void setInside(boolean insideBox) {
		inside=insideBox;
	}
	/**
	 * Checks if the ball is in a box.
	 * @return boolean inside
	 */
	public boolean isInside() {
		return inside;
	}
}
	