package ManyInOne;
import java.util.*;

public class ManyToOneRelation<M, O> {
	public Collection<ObjectLink<M,O>> links = new HashSet<ObjectLink<M,O>>();
/**
* Connects the given source with the given target. If this source was
* previously connected with another target the old connection is lost.
*
* @param source
* @param target
* @return
*/
	
public boolean connect(M source, O target) {
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.object.equals(source)) {
			element.storage=target;
			return true;
		}
	}
	links.add(new ObjectLink<M, O>(source, target));
	return false;
}
/**
* @param source
* @return <code>true</code> if the relation contains the given source
*/
public boolean containsSource(M source) {
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.object.equals(source)) {
			return true;
		}
	}
return false;
}
/**
* @param target
* @return <code>true</code> if the relation contains the given target
*/
public boolean containsTarget(O target) {
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.storage.equals(target)) {
			return true;
		}
	}
return false;
}
/**
* @param source
* @return the target with which this source is connected
*/
public O getTarget(M source) {
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.object.equals(source)) {
			return element.storage;
		}
	}
return null;
}
/*** @param target
* @return all the targets that are connected with this source or empty
*         collection if there are no sources connected with this target.
*/
public Collection<M> getSources(O target) {
	Collection<M> output = new HashSet<M>();
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.storage.equals(target)) {
			output.add(element.object);
		}
	}
	if(output.isEmpty()) return null;
	return output;
}
/**
* Removes the connection between this source and the corresponding target.
* Other sources will still point to the same target.
*
* The target is removed if this was the only source pointing to it and
* {@link #containsTarget(Object)} will return false.
*
* @param source
*/
public void disconnectSource(M source) {
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.object.equals(source)) {
			links.remove(element);
		}
	}
}
/**
* Removes the given target from the relation. All the sources that are
* pointing to this target are also removed.
*
* If you take the "result" of {@link #getSources(target)} and after that
* call this method then {@link #containsSource(Object)} will return
* <code>false</code> for every object in "result".
*
* @param target
*/
public void disconnect(O target) {
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(element.storage.equals(target)) {
			links.remove(element);
		}
	}
}
/**
* @return a collection of the targets.
*/
public Collection<O> getTargets() {
	Collection<O> output = new HashSet<O>();
	Iterator<ObjectLink<M, O>> i = links.iterator();
	while(i.hasNext()) {
		ObjectLink<M, O> element = i.next();
		if(!output.contains(element.storage)) {
		output.add(element.storage);
		}
	}
	if(output.isEmpty()) return null;
	return output;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((links == null) ? 0 : links.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	ManyToOneRelation<M, O> other = (ManyToOneRelation<M, O>) obj;
	if (links == null) {
		if (other.links != null)
			return false;
	} else if (!links.equals(other.links))
		return false;
	return true;
}
}