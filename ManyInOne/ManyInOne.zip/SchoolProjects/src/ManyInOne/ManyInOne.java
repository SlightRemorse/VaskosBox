package ManyInOne;

public class ManyInOne {

	public static void testEqualsTrue() {
		ManyToOneRelation<String, Integer> relation1 = new 
		ManyToOneRelation<String, Integer>();
		ManyToOneRelation<String, Integer> relation2 = new 
		ManyToOneRelation<String, Integer>();
		relation1.connect("Integer1", new Integer(1));
		relation1.connect("Integer2", new Integer(2));
		relation2.connect("Integer1", new Integer(1));
		relation2.connect("Integer2", new Integer(2));
		System.out.println(relation1.equals(relation2)); // should be true
		System.out.println(relation1.hashCode()  == relation2.hashCode()); // should be true
	}
	
	public static void testEqualsFalse() {
		ManyToOneRelation<String, Integer> relation1 = new ManyToOneRelation<String,
		Integer>();
		ManyToOneRelation<String, Integer> relation2 = new ManyToOneRelation<String,
		Integer>();
		relation1.connect("Integer1", new Integer(1));
		relation2.connect("Integer1", new Integer(1));
		relation2.connect("Integer2", new Integer(2));
		System.out.println(relation1.equals(relation2)); // should be false
		}
	
	public static void main(String[] args) {
		testEqualsTrue();
		System.out.println();
		testEqualsFalse();
	}

}
